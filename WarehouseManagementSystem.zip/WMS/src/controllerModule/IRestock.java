package controllerModule;

import java.io.IOException;

public interface IRestock {
    
    public void performRestock(String productName)throws IOException;

}
