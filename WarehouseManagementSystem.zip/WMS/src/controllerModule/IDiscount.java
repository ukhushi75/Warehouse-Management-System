package controllerModule;

public interface IDiscount {
    public double applyDiscount(double initialPrice);
}
