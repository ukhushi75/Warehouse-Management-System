package adminModule;

import java.io.IOException;

/**
 * @author Judy Kalenga
 */

public interface ILogin {
    
    public void login(String username, String password) throws IOException ;

}
