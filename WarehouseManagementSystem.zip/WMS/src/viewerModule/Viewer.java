package viewerModule;

import modelModule.AvailableProductList;

/**
 * @author Judy Kalenga
 */

public abstract class Viewer implements INotify {    
    
}
