package viewerModule;

/**
 * @author Judy Kalenga
 */

public interface INotify {
    
    public void update(); 

}
